﻿namespace InterfacesAndAbstractClasses.Models
{
    public class BurritoDeal : MealDeal
    {
        public string ShreddedMeatType { get; set; }
        public string TortillaType { get; set; }
        public bool Cheese { get; set; }
    }
}
