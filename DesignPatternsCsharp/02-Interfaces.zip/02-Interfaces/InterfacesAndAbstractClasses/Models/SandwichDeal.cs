﻿namespace InterfacesAndAbstractClasses.Models
{
    public class SandwichDeal : MealDeal
    {
        public string ColdCutType { get; set; }
        public string BreadType { get; set; }
        public bool Cheese { get; set; }
    }
}
